<?php

use App\Livewire\Home;
use App\Livewire\Post\Show as PostShow;
use Illuminate\Support\Facades\Route;
use Livewire\Livewire;

Livewire::setUpdateRoute(function ($handle) {
    return Route::post('/fstarter/livewire/update', $handle);
});

Livewire::setScriptRoute(function ($handle) {
    return Route::get('/fstarter/livewire/livewire.js', $handle);
});

Route::get('/', function () { return redirect('/app');})->name('home');

Route::get('/article/{post:slug}', PostShow::class)->name('post.show');
Route::get('/clr', function () {
    $clearcache = Artisan::call('cache:clear');
    echo "Cache cleared<br>";

    $clearview = Artisan::call('view:clear');
    echo "View cleared<br>";

    $clearconfig = Artisan::call('config:cache');
    echo "Config cleared<br>";

    $cleardebugbar = Artisan::call('route:clear');
    echo "Debug Bar cleared<br>";

});

Route::group(['middleware' => ['auth']], function () {
    Route::get('view-invoice/{id?}', [\App\Http\Controllers\AccountController::class, 'getInvoice'])->name('viewinvoice');

    Route::get('view-isps/{id?}', [\App\Http\Controllers\AccountController::class, 'getIsps'])->name('viewisps');

    Route::get('view-dms/{id?}', [\App\Http\Controllers\AccountController::class, 'getDms'])->name('viewdms');

});


