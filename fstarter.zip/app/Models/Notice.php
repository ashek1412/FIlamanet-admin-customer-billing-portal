<?php

namespace App\Models;

use App\Http\Controllers\AccountController;
use Illuminate\Database\Eloquent\Model;



class Notice extends Model
{
    protected $guarded = [];

}
