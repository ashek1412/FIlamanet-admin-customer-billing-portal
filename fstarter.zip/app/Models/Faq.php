<?php

namespace App\Models;

use App\Http\Controllers\AccountController;
use Illuminate\Database\Eloquent\Model;



class Faq extends Model
{
    protected $guarded = [];

}
