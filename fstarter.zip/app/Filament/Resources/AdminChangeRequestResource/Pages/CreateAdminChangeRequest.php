<?php

namespace App\Filament\Resources\AdminChangeRequestResource\Pages;

use App\Filament\Resources\AdminChangeRequestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAdminChangeRequest extends CreateRecord
{
    protected static string $resource = AdminChangeRequestResource::class;
}
