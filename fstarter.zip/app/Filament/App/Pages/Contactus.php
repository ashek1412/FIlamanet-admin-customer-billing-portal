<?php

namespace App\Filament\App\Pages;

use Filament\Pages\Page;

class Contactus extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-document-text';

    protected static string $view = 'filament.app.pages.contactus';

    protected static ?int $navigationSort=8;

    public static function getNavigationLabel(): string
    {
        return 'Contact Us';
    }

    public function getHeading(): string
    {
        return 'Contact Us';
    }
}
