<?php

namespace App\Filament\App\Pages;

use App\Http\Controllers\AccountController;
use Filament\Pages\Page;

class Tracking extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-magnifying-glass';

    protected static string $view = 'filament.app.pages.tracking';
    protected static ?int $navigationSort=2;
    public function getHeading(): string
    {
        return '';
    }

    public $tracking;
    public $trackingReesult=null;

    public function searchTracking(): void
    {
        // dd($this->tracking);
        $this->trackingReesult=[];
        $acc=new AccountController();
        $res=$acc->getTracking($this->tracking);
        if(is_array($res) && count($res)>0) {
            $this->trackingReesult = $res;
        }

    }
}
