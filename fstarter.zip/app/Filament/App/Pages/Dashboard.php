<?php
namespace App\Filament\App\Pages;


use App\Http\Controllers\AccountController;
use App\Models\AccountStatement;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;

class Dashboard extends \Filament\Pages\Dashboard
{
    protected static ?string $navigationIcon = 'heroicon-o-home';
    protected static string $view = 'filament.app.pages.dashboard-page';
    protected static ?int $navigationSort=1;
    protected static ?string $title = 'Dashboard';

    protected $tracking;
    protected $trackingReesult=null;
    public $statementOfAccount;
    public $statusFilter = '';
    public $typeFilter = '';
    public $filteredValue = '';
    protected $cus_code;

    public function getHeading(): string
    {
        $company = (auth()->user()->is_admin)?"Admin Dashboard": auth()->user()->name."'s Dashboard";
        return $company;
    }

    public function getWidgets(): array
    {
        return [
            // Remove or comment out the custom widget
       //      CustomWidget::class,
        ];
    }

    public function mount(): void
    {

        $this->statementOfAccount= $this->getData();
        $this->filteredValue=$this->statementOfAccount;
    }

    public function getData()
    {
        $userId = Auth::id();

        $temp=AccountStatement::all();
        dd($temp);

        $data = Cache::remember("statement_acc_{$userId}", now()->addMinutes(30), function () {
            // Your database query or heavy processing here
            $acController=new AccountController();
            $this->cus_code = $acController->getAccount();
            $this->cus_code=$this->cus_code['xcus'];

            $actColor=New AccountController( );
            $cusData=$actColor->getDynamicsData( $this->cus_code);

            return  $cusData;
        });

        return $data;
    }

    public function updatedStatusFilter()
    {

        $this->filterData();
    }

    public function updatedTypeFilter()
    {

     $this->filterData();
    }

    public function filterData()
    {
        if($this->statusFilter!="" && $this->typeFilter!="")
        {   $data=$this->statementOfAccount;
            $filtered = array_filter($data, function($value) {
                return $value['invoiceType'] == $this->typeFilter;
            });

            $filtered = array_filter($filtered, function($value) {
                return $value['status'] == $this->statusFilter;
            });

            $this->filteredValue=$filtered;
        }
        else if($this->statusFilter!="")
        {
            $data=$this->statementOfAccount;
            $filtered = array_filter($data, function($value) {
                return $value['status'] == $this->statusFilter;
            });

            $this->filteredValue=$filtered;
        }
        else if($this->typeFilter!="")
        {
            $data=$this->statementOfAccount;
            $filtered = array_filter($data, function($value) {
                return $value['invoiceType'] == $this->typeFilter;
            });

            $this->filteredValue=$filtered;
        }
        else
        {
            $this->filteredValue=$this->statementOfAccount;
        }
    }





    public function searchTracking(): void
    {
           // dd($this->tracking);
            $this->trackingReesult=[];
            $acc=new AccountController();
            $res=$acc->getTracking($this->tracking);
            if(is_array($res) && count($res)>0) {
                $this->trackingReesult = $res;
            }

    }
}
