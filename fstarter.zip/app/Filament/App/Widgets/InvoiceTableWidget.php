<?php

namespace App\Filament\App\Widgets;

use App\Models\Invoice;

use Filament\Tables;
use Filament\Tables\Actions\Action;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\On;

class InvoiceTableWidget extends BaseWidget
{


    protected $listeners = ['refreshtable' => '$refresh'];

    protected int | string | array $columnSpan = 'full';

    public $invno=null;
    public function table(Table $table): Table
    {
        return $table
            ->query(
               Invoice::query()
            )
            ->columns([

                TextColumn::make('xdate')->label('date')->date("Y-m-d")->searchable()->sortable(),
                TextColumn::make('xpbdocno')->label('tracking')->searchable(),
                TextColumn::make('xadd')->label('shipper'),
//                TextColumn::make('xadd')->label('consignee'),
                TextColumn::make('xcountry')->label('lane')->searchable()->sortable(),
                TextColumn::make('xpbdoctype')->label('package')->searchable()->sortable(),
                TextColumn::make('xnum')->label('pcs')->searchable()->sortable()->sortable(),
                TextColumn::make('xpbwtf')->label('weight')->searchable()->numeric('2')->suffix('Kg')->sortable()
            ])->actions([
                // Define the custom action
                Action::make('view')
                    ->label('DWS')
                    ->icon('heroicon-o-eye')  // Icon (optional)
                    ->color('primary')  // Red color (optional)
                    ->url(fn (Invoice $record): string => route('viewisps', ['id' =>$record['xpbdocno']]))

                    ->openUrlInNewTab(),

                Action::make('view')
                    ->label('AWB Scan')
                    ->icon('heroicon-o-eye')  // Icon (optional)
                    ->color('primary')  // Red color (optional)
                    ->url(fn (Invoice $record): string => route('viewdms', ['id' =>$record['xpbdocno']]))

                    ->openUrlInNewTab(),


            ])
            ->heading(Session::get('cur_invno'));
    }



    protected function getColumns(): int | array
    {
        return 4;
    }

    #[On('update-detail')]
    public function updateInvoice($invno=null)
    {
     //   dd($invno);
        $this->invno=$invno;
    }






}
