<?php

namespace App\Http\Controllers;


use App\Services\DynamicsService;
use Exception;
use Filament\Notifications\Notification;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request as GuzzleRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;

class AccountController extends Controller
{

    private $headers;
    private $erp_url;
    private $dms_url;



    public function __construct()
    {
        $this->headers = [
            'Accept' => '*/*',  // Accept header to specify that we want JSON response
            'ebill-id' => config('app.ebil_id') ,  // Example of a custom header
            'ebill-key' => config('app.ebil_key'),  // Example of a custom header
            'client-did' => Auth::user()->customer_id
        ];

        $this->erp_url=config('app.erp_url');
        $this->dms_url=config('app.dms_url');

    }


    public function getAccount()
    {
        try {
        $result = [];


        // Make the API request with the headers
        $response = Http::withHeaders($this->headers)->post($this->erp_url.'/customer', ['cid' => Auth::user()->customer_id]);

            //dd($response->json('data'));
            // Check if request was successful
            if ($response->successful()) {
                $result = $response->json('data'); // Return the API response as an array

            }
            else
            {
                Notification::make()
                    ->title('Failed to retrieve data ')
                    ->danger()
                    ->send();
            }

        } catch (\Exception $e) {
            Log::error('API Error: ' . $e->getMessage());
            Notification::make()
                ->title('API Error')
                ->danger()
                ->send();
        }

        return $result;
    }

    public function getInvoiceList()
    {
        $result = [];

        try {
                // Make the API request with the headers
                $response = Http::withHeaders($this->headers)->post($this->erp_url.'/invoices', ['cid' => Auth::user()->customer_id]);

                // Check if request was successful
                if ($response->successful()) {
                    $result = $response->json('data'); // Return the API response as an array
                }
                else
                {
                    $errorMessage = $response->body();
                    echo($errorMessage);

                    Notification::make()
                        ->title('Failed to retrieve data ')

                        ->danger()
                        ->send();
                }

            } catch (\Exception $e) {
                Log::error('API Error: ' . $e->getMessage());
                Notification::make()
                ->title('API Error')
                ->danger()
                ->send();
        }
        return $result;
    }

    public function getCustomerList()
    {
        $result = [];
        try {

        // Make the API request with the headers
             $response = Http::withHeaders($this->headers)->post($this->erp_url.'/clist', ['cid' => Auth::user()->is_admin]);


            // Check if request was successful
            if ($response->successful()) {
                $result = $response->json('data'); // Return the API response as an array

            }
            else
            {
                Notification::make()
                    ->title('Failed to retrieve data ')
                    ->danger()
                    ->send();
            }

        } catch (\Exception $e) {
            Log::error('API Error: ' . $e->getMessage());
            Notification::make()
                ->title('API Error')
                ->danger()
                ->send();
        }
        return $result;
    }

    public function getInvoice($id = null)
    {
        try {
            if ($id > 0) {
                // Make the API request with the headers
                $response = Http::withHeaders($this->headers)->post($this->erp_url.'/invoice', ['invnum' => $id]);

                if ($response->successful()) {

                  //  dd($response->json()['pdf_data']);
                    $pdfData = base64_decode($response->json()['pdf_data']);
                    // Return the PDF response with the correct headers

                   if($pdfData=="")
                       return response()->json([
                           'message' => 'Document not found',
                       ], 404);

                    return Response::make($pdfData, 200, [
                        'Content-Type' => 'application/pdf',
                        'Content-Disposition' => 'inline; filename="' . $id . '.pdf"',
                    ]);
                }
                else
                {
                    return response()->json([
                        'message' => 'Failed to retrieve data',
                    ], 404);

                }
            }
        } catch (\Exception $e) {
            Log::error('API Error: ' . $e->getMessage());
            return response()->json([
                'message' => 'API Error Failed to retrieve data',
            ], 404);
        }

    }

    public function getIsps($id = null)
    {
        if ($id > 0)
        {
            try {


                // Make the API request with the headers
                $response = Http::withHeaders($this->headers)->post($this->erp_url . '/ispsdet', ['id' => $id]);

                if ($response->successful()) {

                    $pdfData = base64_decode($response->json()['pdf_data']);

                    if(!empty($pdfData)) {
                        // Return the PDF response with the correct headers
                        return Response::make($pdfData, 200, [
                            'Content-Type' => 'application/pdf',
                            'Content-Disposition' => 'inline; filename="' . $id . '.pdf"',
                        ]);
                    }
                    else
                        return response()->json([
                            'message' => 'Document not found',
                        ], 404);
                }
                else
                {
                    return response()->json([
                        'message' => 'Failed to retrieve data',
                    ], 404);

                }

            }
             catch (\Exception $e) {
                Log::error('API Error: ' . $e->getMessage());
                 return response()->json([
                     'message' => 'API Error Failed to retrieve data',
                 ], 404);
            }
        }
    }

    public function getTracking($id = null)
    {

        if ($id > 0)
        {
            try
            {

                // Make the API request with the headers
                $response = Http::withHeaders($this->headers)->post($this->erp_url.'/tracking', ['id' => $id]);


                // Check if request was successful
                if ($response->successful()) {
                    $result = $response->json('data'); // Return the API response as an array

                }
                else
                {
                    Notification::make()
                        ->title('Failed to retrieve data ')
                        ->danger()
                        ->send();
                }
            } catch (\Exception $e) {
                Log::error('API Error: ' . $e->getMessage());
                Notification::make()
                    ->title('API Error')
                    ->danger()
                    ->send();
            }
        }

        return $result;
    }

    public function getInvoiceDetails()
    {

        $id = Session::get('cur_invno');

        $result=[];
        try {


        if ($id > 0) {

            $response = Http::withHeaders($this->headers)->post($this->erp_url.'/invoicedet', ['invnum' => $id]);
            // Check if request was successful
            if ($response->successful()) {
                $result = $response->json('data'); // Return the API response as an array

            }
            else
            {

                Notification::make()
                    ->title('Failed to retrieve data ')
                    ->danger()
                    ->send();
            }


        }
        } catch (\Exception $e) {
            Log::error('API Error: ' . $e->getMessage());
            Notification::make()
                ->title('API Error')
                ->danger()
                ->send();
        }
           return $result;
    }

    public function getDms($id = null)
    {
        $tracking_data= $this->getTracking($id);

        if(!empty($tracking_data) && count($tracking_data)>0) {

            if (!session()->has('dms_tok')) {
                $this->getAwbScanToken();
            }

            if (session()->has('dms_tok')) {
                $res = $this->getAwbScanDocID($id);


                if ($res == "403") {
                    $this->getAwbScanToken();
                    $doc_id = $this->getAwbScanDocID($id);

                    if ($doc_id > 0) {
                        $this->downloadAwbScan($doc_id, $id);
                    }
                    else
                    return response()->json([
                        'message' => 'Document not found',
                    ], 404);
                } else {
                    if ($res > 0) {
                        $this->downloadAwbScan($res, $id);
                    }
                    else
                    return response()->json([
                        'message' => 'Document not found',
                    ], 404);
                }

            }
        }
        else
            return response()->json([
                'message' => 'Document not found',
            ], 404);



    }

    public function getAwbScanToken()
    {
           $response = Http::post($this->dms_url.'/token/', [
                'username' => config('app.dms_user'),
                'password' => config('app.dms_pass')
            ]);


            if ($response->successful()) {

              //  dd($response->json('access'));
                Session::put('dms_tok', $response->json('access'));

             }
            else
            {
                Notification::make()
                    ->title('Failed to retrieve data ')
                    ->danger()
                    ->send();
            }

    }

    public function getDynamicsData($cus_code=null)
    {


        $dynamicsTokenService = new DynamicsService();
        $accessToken = $dynamicsTokenService->getAccessToken();

              $fromDate = "2024-07-01";
              $toDate = "2025-07-31";


        try {



            $baseUrl = config('app.dynamics_api_url');
            // Entity name spelling corrected if needed
            $entity = 'SatementOfAccounts';
            // Build the URL safely
            $url = $baseUrl . "/Company('" . urlencode("AAL_LIVE") . "')/$entity";
            $filter = "\$filter=invoiceDate ge $fromDate and invoiceDate le $toDate";
            $fullUrl = $url."?".$filter;
            $client = new Client();
            $headers = [
                'Authorization' => 'Bearer '.$accessToken
            ];
            $request = new GuzzleRequest('GET', $fullUrl, $headers);
            $response = $client->sendAsync($request)->wait();


            if ($response->getStatusCode() >= 200 && $response->getStatusCode() < 300) {
                $body = $response->getBody();
                $bodyString = (string) $body;
                $data = json_decode($bodyString, true);

                $result=$data['value'];

                $results=[];


                if(count($result)>0)
                {



                    $searchRole=$cus_code;


                    foreach ($result as $item) {
                        if ($item['customerCode'] == $searchRole) {
                            $results[] = $item;
                        }
                    }



                }
                return $results;

            } else {
                dd("Error: " . $response->getStatusCode());
            }


        } catch (\Exception $e) {

            dd(response()->json(['error' => $e->getMessage()], 500));
        }



    }

    public function getAwbScanDocID($id = null)
    {

             $doc_id=0;
            if ($id > 0) {

                try {

                    $client = new Client();


                    $response = $client->request('POST',$this->dms_url . '/v1/dms/documents/search/',
                        [

                            'headers' => [
                                'Authorization' => 'JWT ' . Session::get('dms_tok')
                            ],
                            'multipart' =>[
                                [
                                    'name' => 'search_type',
                                    'contents' => 'standard'
                                ],
                                [
                                    'name' => 'keyword',
                                    'contents' => $id
                                ]
                            ]

                    ]);





                    $status_code=$response->getStatusCode();



                    if ($status_code == "403")
                        return $status_code;
                    if ($status_code=="200" ) {

                        $responseBody = $response->getBody()->getContents();


                        if(strlen($responseBody)==0)
                        {
                            return $doc_id;
                        }
                        else {


                            $responseData = json_decode($responseBody, true);
                            $doc_id = $responseData['data'][0]['document_id'];
                        }


                    } else {

                        return $doc_id;
                    }



                } catch (\Exception $e) {

                 //  dd($e->getMessage());
                    if($e->getCode()=="403")
                    {
                       return  $e->getCode();
                    }
                    Log::error('API Error: ' . $e->getMessage());

                }
            }
        return $doc_id;
    }

    public function downloadAwbScan($id = null, $awb=null)
    {

        if ($id > 0) {

            try {

                $client = new Client();

                $response = $client->request('GET',$this->dms_url . '/v1/dms/documents/external/download/',
                    [
                        'headers' => [
                            'Authorization' => 'JWT ' . Session::get('dms_tok')
                        ],
                        'multipart' =>[
                            [
                                'name' => 'document_id',
                                'contents' => $id
                            ]
                        ]
                    ]);


                $status_code=$response->getStatusCode();


                if ($status_code == "403")
                    return $status_code;
                if ($status_code=="200") {



                    // Return the PDF response with the correct headers

                    $responseBody = $response->getBody()->getContents();


                    $responseData = json_decode($responseBody, true);


                    $pdfData = base64_decode($responseData['data']);

                    // Specify the output file path
                    $outputFilePath = 'output.pdf';

                    header('Content-Type: application/pdf');
                    header('Content-Disposition: inline; filename="scan_'.$awb.'".pdf"');
                    header('Content-Length: ' . strlen($pdfData));


                    echo $pdfData;
                    exit;

                } else {
                    Notification::make()
                        ->title('Failed to retrieve data ')
                        ->danger()
                        ->send();
                }



            } catch (\Exception $e) {

                //  dd($e->getMessage());
                Log::error('API Error: ');
                Notification::make()
                    ->title('API Error')
                    ->danger()
                    ->send();
            }
        }
    }



}
