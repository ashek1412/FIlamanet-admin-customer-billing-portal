<x-filament-panels::page>
  <div class="space-y-4">
  {{$this->form}}
  </div>
  <div class="w-48">
    <x-filament::button wire:click="updateForm" size="sm">
      Save
    </x-filament::button>
    <div class="space-y-4">
</x-filament-panels::page>
