<x-filament-panels::page>
{{--  <div class="row justify-content-center w-full">--}}
{{--    @if(strlen($rpturl)>0)--}}
{{--      <iframe src="{{ $rpturl }}" width="100%"  style="overflow:hidden; height: 100vh;width:100%"></iframe>--}}

{{--    @endif--}}

{{--  </div>--}}
</x-filament-panels::page>
