<x-filament-panels::page>



  <div class="flex items-center space-x-4 justify-center">
    <label for="username" class="text-md
     font-semibold text-gray-800  dark:bg-black dark:text-white">Statement of accounts</label>

  </div>

  <div class="text-sm flex items-center space-x-4 justify-center ">

    @if((is_array($statementOfAccount) && count($statementOfAccount)>0))


      <div class="flex overflow-y-auto max-h-96 w-11/12 justify-center ">

        <table class="w-full divide-y divide-gray-200 dark:bg-gray-700 dark:text-white border-collapse">
          <thead class="bg-gray-100 text-slate-800 ">
          <tr class="divide-x divide-gray-200 dark:bg-gray-700 dark:text-white">
            <th class="px-1 py-2 w-10 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow ">Sl no</th>
            <th class="px-1 py-2 w-32 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow">Account</th>
            <th class="px-1 py-2 w-28 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow">Invoice Type</th>
            <th class="px-1 py-2 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow">Invoice Period</th>
            <th class="px-1 py-2 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow">Invoice Date</th>
            <th class="px-1 py-2 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow">Due Date</th>
            <th class="px-1 py-2 w-28 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow ">Invoice Amount</th>
            <th class="px-1 py-2 w-32 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow">Settled Amount</th>
            <th class="px-1 py-2 w-32 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow">Due Amount</th>
            <th class="px-1 py-2 w-24 sticky top-0 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow">Status</th>
          </tr>
            <tr class="divide-x divide-gray-200 bg-white dark:bg-gray-700">
              <th class="px-1 py-0   sticky top-8 bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow "></th>
              <th class="px-1 py-0  sticky top-8  bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow"></th>
              <th class="px-1 py-0  sticky top-8  bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow">
                <select wire:model.live="typeFilter" class="w-full leading-tight px-1 py-0.5 text-xs dark:bg-gray-700 dark:text-white">
                  <option value="">All</option>
                  <option value="Export">Export</option>
                  <option value="Import">Import</option>

                </select>

              </th>
              <th class="px-1 py-0  sticky top-8  bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow"></th>
              <th class="px-1 py-0  sticky top-8  bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow"></th>
              <th class="px-1 py-0  sticky top-8  bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow"></th>
              <th class="px-1 py-0  sticky top-8  bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow "></th>
              <th class="px-1 py-0  sticky top-8  bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow"></th>
              <th class="px-1 py-0  sticky top-8  bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow"></th>
              <th class="px-1 py-0  sticky top-8  bg-gray-100 dark:bg-gray-600 dark:text-white z-10 shadow" >
                <select wire:model.live="statusFilter" class="w-full leading-tight px-1 py-0.5 text-xs dark:bg-gray-700 dark:text-white">
                  <option value="">All</option>
                  <option value="Paid">Paid</option>
                  <option value="Over Due">Over Due</option>
                  <option value="Pending">Pending</option>
                </select>
                </th>

            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200 bg-white">
          @foreach($filteredValue as $key=>$statement)
            <tr class="divide-x divide-gray-200 dark:bg-gray-700 dark:text-white ">
              <td class="px-2 py-2">{{$key+1}}</td>
              <td class="px-2 py-2">{{$statement['icris']}}</td>
              <td class="px-2 py-2">{{$statement['invoiceType']}}</td>
              <td class="px-2 py-2">{{$statement['invoicePeriod']}}</td>
              <td class="px-2 py-2">{{$statement['invoiceDate']}}</td>
              <td class="px-2 py-2">{{$statement['dueDate']}}</td>
              <td class="px-2 py-2">{{$statement['invoiceAmount']}}</td>
              <td class="px-2 py-2">{{$statement['settledAmount']}}</td>
              <td class="px-2 py-2">{{$statement['dueAmount']}}</td>
              <td class="px-2 py-2 font-semibold">
            <span class="@if($statement['status'] == 'Over Due') text-red-700
          @elseif($statement['status'] == 'Paid') text-green-500
          @else text-black
          @endif
          ">

            {{$statement['status']}}
            </span>
              </td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    @endif
  </div>
</x-filament-panels::page>

