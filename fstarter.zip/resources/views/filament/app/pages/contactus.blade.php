<x-filament-panels::page>
  <div class="ml-4">
    <span class="font-bold">Address: </span>
    <br>
  Air Alliance Limited<br>
  Authorised Service Contractor for UPS<br>
  Bilquis Tower, Level 6,<br>
  6 North Gulshan C/A,<br>
  Gulshan Circle-2, Dhaka-1212, Bangladesh <br><br>

    <span class="font-bold"> Customer Service: </span>
 <br>
  Hotline: 16729<br>
  Operating Hours: 8 AM to 11 PM

  </div>

</x-filament-panels::page>
