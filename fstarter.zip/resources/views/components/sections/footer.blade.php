<footer class="py-8 mt-8 border-t bg-gray-50 justify-self-end">
  <x-container>
    <div class="text-xs text-gray-800/50">
      &copy; {{ date('Y') }} {{ config('app.name') }}
    </div>
  </x-container>
</footer>
