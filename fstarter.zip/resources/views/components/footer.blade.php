<footer class="w-full py-4 text-center text-sm text-gray-500">
  © {{ date('Y') }} Your Company Name. All rights reserved.
</footer>
