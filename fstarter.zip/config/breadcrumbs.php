<?php

return [
    'view' => 'partials.breadcrumb',
];
