<?php

return [
    'icons' => [
        'navigation' => 'heroicon-o-exclamation-triangle',
        'exception' => 'heroicon-o-exclamation-triangle',
        'headers' => 'heroicon-o-arrows-right-left',
        'cookies' => 'heroicon-o-circle-stack',
        'body' => 'heroicon-s-code-bracket',
        'queries' => 'heroicon-s-circle-stack',
    ],
];
